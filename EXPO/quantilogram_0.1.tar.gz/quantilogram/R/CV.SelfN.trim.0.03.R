##' Critical Values for the Self-Normalized Statistics with a trimming value 0.03
##'
##' See the explanation in CV.SelfN.trim.0.00
##'
##' @docType data
##' @keywords datasets
##' @name CV.SelfN.trim.0.03
NULL

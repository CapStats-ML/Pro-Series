##' The partial cross-quantilograms from 1 to a given lag order.
##'
##' This function calculates the partial cross-quantilograms up to the lag order
##' users specify.
##' @title Partial Corss-Quantilogram upto a given lag order
##' @param DATA An input matrix 
##' @param vecA A vector of probability values at which sample quantiles are estimated
##' @param Kmax The maximum lag order (integer)
##' @return A vector of cross-quantilogram and a vector of partial cross-quantilograms
##' @author Heejoon Han, Oliver Linton, Tatsushi Oka and Yoon-Jae Whang
##' @export 
CrossQ.max.partial = function(DATA, vecA, Kmax)
{
  ## Quantile Hit process with demean
  matH = Qhit(DATA, vecA)
  
  ## (3) for each lag
  vecCRQ    = matrix(0, Kmax, 1)
  vecParCRQ = matrix(0, Kmax, 1)

  for (k in 1:Kmax){

    ## cross-quantilogram of lag order k
    RES          = Corr.partial(matH, k)
    vecCRQ[k]    = RES$CRQ
    vecParCRQ[k] = RES$ParCRQ

  }

  ## list
  list(CRQ = vecCRQ, ParCRQ = vecParCRQ)

}  ## EoF

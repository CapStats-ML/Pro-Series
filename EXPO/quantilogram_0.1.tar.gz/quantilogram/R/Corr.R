##' The correlation statistics for a given lag order 
##'
##' The function obtains the simple correlation statistics. The values in the first column of input matrix
##' is interacted with the k-lagged values in the second column.
##' @title Correlation Function
##' @param matH The matrix with the column size of 2 
##' @param k    The lag order (integer)
##' @return Correlation 
##' @author Heejoon Han, Oliver Linton, Tatsushi Oka and Yoon-Jae Whang
##' @export 
Corr = function(matH, k)
{
  ## size
  Tsize = nrow(matH)    ## =: T
  Nsize = Tsize - k

  ##  {H_1t, H_2t-k}
  matD     = matrix(0, Nsize, 2)
  matD[,1] = matH[(k+1):Tsize, 1, drop=FALSE]
  matD[,2] = matH[    1:Nsize, 2, drop=FALSE]
  
  ## the following matrix contains inner-products of two vectors in H.
  matDD  = t(matD) %*% matD ## 

  ## cross-quantilogram of lag order k
  CRQ =  matDD[1,2] / sqrt( matDD[1,1] * matDD[2,2] ) ## 1 x 1
  
  ## list
  return(CRQ)

} ## EoF

##' Critical Values for the Self-Normalized Statistics with a trimming value 0.20
##'
##' See the explanation in CV.SelfN.trim.0.00
##'
##' @docType data
##' @keywords datasets
##' @name CV.SelfN.trim.0.20
NULL

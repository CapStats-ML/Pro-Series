##' Critical Values for the Self-Normalized Statistics with a trimming value 0.00
##'
##' The critical values are obtained via simulation. The Brownian bridge are approximated 
##' by 5,000 normali distribution and the number of repetition is 500,000 to obtain the
##' critical values. 
##'
##'
##' \itemize{
##'   \item dim:     The number of restrictions imposed under the null hypothesis
##'   \item sig0.10:  The critical value for the 0.10 significance level
##'   \item sig0.05:  The critical value for the 0.05 significance level
##'   \item sig0.025: The critical value for the 0.025 significance level
##'   \item sig0.01:  The critical value for the 0.01 significance level
##'   \item sig0.005: The critical value for the 0.005 significance level
##' }
##'
##' @docType data
##' @keywords datasets
##' @name CV.SelfN.trim.0.00
##' @usage data(CV.SelfN.trim.0.00)
NULL

##' Returns the self-normalized version of the partial cross-quantilogram 
##'
##' This function obtains the self-normalized version of the partial cross-quantilogram
##' at a given lag order.
##' @title Self-Normalized Partial Cross-Quantilogram
##' @param DATA An input matrix
##' @param vecA A pair of two probabilities at which sample quantiles are estimated
##' @param k    A lag order 
##' @param scaW A triming value specifiying the fraction of the sample which corresponds to the minimum subsample size 
##' @return The self-normalized partial cross-quantilogram
##' @author Heejoon Han, Oliver Linton, Tatsushi Oka and Yoon-Jae Whang
##' @export 
CrossQ.partial.SelfN = function(DATA, vecA, k, scaW)
{
    ## sample size
    Tsize = nrow(DATA) ## =:T
    Nvar  = ncol(DATA) ## =:N

    ## the number of trimming parameters
    TWsize = round(scaW * Tsize)
    
    ##===================================================================
    ## recursive objects
    ##===================================================================
    seqCRQ = matrix(0, Tsize, 1) ## T x 1
    
    for (s in TWsize:Tsize){
        
      ## choose subsample from 1 to s
      subDATA = DATA[1:s,]   ## s x 2
      
      ## corss-Q
      RES       = CrossQ.partial(subDATA, vecA, k)
      seqCRQ[s] = RES$ParCRQ
      
    }
    
    ## cross-quantilograms for lag k
    vCRQ = seqCRQ[Tsize] ## 1 x 1 
    
    ## to make it center (Brownian bridge in asymptotics)
    vec1T = matrix( c(1:1:Tsize), Tsize, 1)                   ## T x 1
    vecBB = ( seqCRQ - matrix(1, Tsize,1) %*% vCRQ ) * vec1T  ## T x 1
    
    ##===================================================================
    ## self-normalization statistics
    ##===================================================================
    ## denominator
    tempBB     = vecBB[TWsize:Tsize]                    
    vVar       = (1 / Tsize^2) * ( t(tempBB) %*% tempBB ) ## 1 x 1
    vCRQ.SN    = Tsize * vCRQ^2 / vVar

    list(vParCRQ = vCRQ, vParCRQ.SN =  vCRQ.SN)
} ## EoF

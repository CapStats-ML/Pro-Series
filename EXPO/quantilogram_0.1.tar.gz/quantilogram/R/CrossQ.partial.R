##' Returns the partial cross-quantilogram 
##'
##' This function obtains the partial corss-quantilogram and the cross-quantilogram.
##' To obtain the partial cross-correlation given an input matrix, this function interacts
##' the values of the first column and the k-lagged values of the rest of the matrix.
##' @title Paritial Cross-Quantilogram
##' @param DATA A matrix 
##' @param vecA A vector of probability values at which sample quantiles are estiamted 
##' @param k    The lag order 
##' @return The partial corss-quantilogram and the cross-quantilogram
##' @author Heejoon Han, Oliver Linton, Tatsushi Oka and Yoon-Jae Whang
##' @export 
CrossQ.partial = function(DATA, vecA, k)
{
  ## Important idea: make hit first
  ## Quantile Hit process with demean
  matH = Qhit(DATA, vecA)
  
  ## cross-quantilogram of lag order k
  RES = Corr.partial(matH, k)

  ## list
  list(CRQ    = RES$CRQ,
       ParCRQ = RES$ParCRQ  )

}  ## EoF

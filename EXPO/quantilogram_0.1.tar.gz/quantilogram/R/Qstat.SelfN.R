##' The self-normalized version of the Q-statistics 
##' 
##' This function returns the self-normalized Q-statistics.
##' @title Self-normalized Q-statistics
##' @param DATA The original data
##' @param vecA A pair of two probability values at which sample quantiles are estimated  
##' @param Kmax The maximum lag order
##' @param vW   A triming value for the self-normalization
##' @return The self-normalized Q-statistics 
##' @author Heejoon Han, Oliver Linton and Tatsushi Oka, Yoon-Jae Whang
##' @export 
Qstat.SelfN= function(DATA, vecA, Kmax, vW)
{
  ## sample size
  Tsize = nrow(DATA)                 ## =: T
  Tw    = max( round(Tsize * vW), 1) ## =: [Tw]
  
  ##==================================================================
  ## recursive objects
  ##==================================================================
  matCQseq = matrix(0, Tsize, Kmax) ## T x K
  
  for (s in Tw:Tsize){

    ## cross-Q based on subsample from 1 to s
    matCQseq[s,] = CrossQ.max(DATA[1:s,], vecA, Kmax)        
    
  }
    
  ## cross-quantilograms for lags from 1 to K
  vecCRQ = t(matCQseq[Tsize,,drop=FALSE]) ## K x 1 (transpose is ncessary)
  
  ## to make it center (Brownian bridge in asymptotics)
  vec1T = matrix( c(1:1:Tsize), Tsize, 1)
  mat1T = vec1T %*% matrix(1, 1, Kmax)        ## T x K
  matBB = ( matCQseq - matrix(1, Tsize,1) %*% t(vecCRQ) ) * mat1T ## T x K
  
  ##====================================================================
  ## self-normalization statistics
  ##====================================================================
  ## container
  vecQ.SN = matrix(0, Kmax, 1)  ## joint test upto kth lag
  
  ## denominator
  tempBB = matBB[Tw:Tsize,]                         ## Tw x K
  matV   = (1 / Tsize^2) * ( t(tempBB) %*% tempBB ) ##  K x K
  
  ## Self-normalized cross Q
  for (k in 1:Kmax){
    
    ## = = = Omnibus test of cross-quantilogram from lag 1 to k = = =
    tempQ = vecCRQ[1:k]              ## 1 x k
    invV  = solve( matV[1:k,1:k] )  ## k x k
    
      ## SNQ
    vecQ.SN[k] = Tsize * t(tempQ) %*% invV %*% tempQ
    
  }

  list(vecCRQ = vecCRQ, vecQ.SN = vecQ.SN)
} ## Eof

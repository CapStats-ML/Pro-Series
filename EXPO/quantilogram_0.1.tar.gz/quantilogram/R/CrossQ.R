##' Returns the cross-quantilogram 
##'
##' This function obtains the cross-quantilogram at the k lag order.
##' @title Cross-Quantilogram
##' @param DATA An input matrix
##' @param vecA A pair of two probability values at which sample quantiles are estimated
##' @param k    A lag order (integer)
##' @return Cross-Quantilogram
##' @author Heejoon Han, Oliver Linton, Tatsushi Oka and Yoon-Jae Whang
##' @export 
CrossQ = function(DATA, vecA, k)
{
  ## Quantile Hit process with demean
  matQhit = Qhit(DATA, vecA)

  ## correlation
  vCRQ    =  Corr(matQhit, k)

  ## 
  return(vCRQ)  ## K x 1

}  ## EoF

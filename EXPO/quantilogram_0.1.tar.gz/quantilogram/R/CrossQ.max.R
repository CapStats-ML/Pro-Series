##' The cross-quantilograms from 1 to a given lag order.
##'
##' This function calculates the partial cross-quantilograms up to the lag order
##' users specify.
##' @title Corss-Quantilogram up to a Given Lag Order
##' @param DATA An input matrix 
##' @param vecA A pair of two probability values at which sample quantiles are estimated
##' @param Kmax The maximum lag order (integer)
##' @return A vector of cross-quantilogram
##' @author Heejoon Han, Oliver Linton, Tatsushi Oka and Yoon-Jae Whang
##' @export 
CrossQ.max = function(DATA, vecA, Kmax)
{
    ## Important idea: make hit first
    ## Quantile Hit process with demean
    matQhit = Qhit(DATA, vecA)
  
    ## for each lag
    vecCRQ = matrix(0, Kmax, 1)  ## K x 1
    
    for (k in 1:Kmax){
        
        ## cross-quantilogram of lag order k
        vecCRQ[k] =  Corr(matQhit, k)
    }

    ## 
    return(vecCRQ)  ## K x 1

}  ## EoF
